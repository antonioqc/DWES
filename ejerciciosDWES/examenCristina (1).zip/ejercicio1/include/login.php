<?php
echo "<h2>Login</h2>";
    echo "<form action='index.php' method='post'>";
        echo "<p></p>Usuario:<input type='text' name='user'></p>";
        echo "<p>Contraseña:<input type='text' name='pass'></p>";
        echo "<p></p><input type='submit' name='iniciarSesion' value='Iniciar Sesion'></p>";
    echo "</form>";
?>


