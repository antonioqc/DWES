<?php
echo "<header><h1>Obras de teatro</h1><p>Hola ".$_SESSION["user"]." estás como ".$_SESSION["perfil"]."</p></header>";
?>