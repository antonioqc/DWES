<?php
    define("DBHOST", "localhost");
    define("DBUSER", "root");
    define("DBPASS", "");
    define("DBNAME", "ex_teatro");
    define("DBPORT", 3306);	
?>